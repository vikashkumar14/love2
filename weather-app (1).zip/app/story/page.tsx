"use client"

import { useState, useEffect } from "react"
import { ArrowLeft, Music, MicOffIcon as MusicOff } from "lucide-react"
import LoveNotes from "@/components/love-notes"
import HeartAnimation from "@/components/heart-animation"
import StoryShayariGrid from "@/components/story-shayari-grid"
import WaterfallEffect from "@/components/waterfall-effect"
import ParticleBackground from "@/components/particle-background"

export default function StoryPage() {
  const [isPlaying, setIsPlaying] = useState(false)
  const [audio, setAudio] = useState<HTMLAudioElement | null>(null)

  useEffect(() => {
    // Initialize audio on client side
    const audioElement = new Audio("/love-song.mp3")
    audioElement.loop = true
    setAudio(audioElement)

    return () => {
      if (audioElement) {
        audioElement.pause()
        audioElement.src = ""
      }
    }
  }, [])

  const toggleMusic = () => {
    if (!audio) return

    if (isPlaying) {
      audio.pause()
    } else {
      audio.play()
    }
    setIsPlaying(!isPlaying)
  }

  return (
    <main className="min-h-screen overflow-x-hidden relative">
      {/* Animated Background */}
      <div className="fixed inset-0 bg-gradient-to-br from-rose-500 via-pink-500 to-orange-400 bg-size-200 animate-gradient-xy -z-10"></div>

      <ParticleBackground />
      <WaterfallEffect />

      <div className="container mx-auto px-4 py-8">
        <h1 className="font-dancing text-5xl md:text-7xl text-center text-white font-bold mb-8 animate-float drop-shadow-glow">
          For My Love Renu ❤️
        </h1>

        <div className="flex justify-center mb-12">
          <HeartAnimation isStory={true} />
        </div>

        <div className="text-center mb-16">
          <h2 className="font-great-vibes text-6xl md:text-8xl bg-gradient-to-r from-white to-yellow-300 bg-clip-text text-transparent drop-shadow-md mb-4 animate-float relative inline-block">
            Renu – मेरी मोहब्बत की कहानी
            <span className="absolute -right-10 top-0 text-4xl animate-heartbeat">❤️</span>
          </h2>
        </div>

        <LoveNotes />

        <StoryShayariGrid />

        {/* Music Control Button */}
        <button
          onClick={toggleMusic}
          className="fixed bottom-6 right-6 bg-white/20 backdrop-blur-md p-3 rounded-full shadow-glow hover:bg-white/30 transition-all z-50"
          aria-label={isPlaying ? "Pause Music" : "Play Music"}
        >
          {isPlaying ? <MusicOff className="text-white" /> : <Music className="text-white" />}
        </button>

        {/* Back to Home Link */}
        <div className="fixed bottom-6 left-6 z-50">
          <a
            href="/"
            className="inline-flex items-center bg-gradient-to-r from-pink-500 to-rose-500 text-white font-dancing text-xl px-6 py-3 rounded-full shadow-glow hover:shadow-glow-lg transform hover:scale-105 transition-all"
          >
            <ArrowLeft className="mr-2" /> Back to Home
          </a>
        </div>
      </div>
    </main>
  )
}

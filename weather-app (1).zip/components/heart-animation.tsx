"use client"

import { useEffect, useRef } from "react"

interface HeartAnimationProps {
  isStory?: boolean
}

export default function HeartAnimation({ isStory = false }: HeartAnimationProps) {
  const heartRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const heart = heartRef.current
    if (!heart) return

    // Add 3D rotation on mousemove
    const handleMouseMove = (e: MouseEvent) => {
      const xAxis = (window.innerWidth / 2 - e.pageX) / 25
      const yAxis = (window.innerHeight / 2 - e.pageY) / 25
      heart.style.transform = `rotateY(${xAxis}deg) rotateX(${yAxis}deg)`
    }

    document.addEventListener("mousemove", handleMouseMove)

    return () => {
      document.removeEventListener("mousemove", handleMouseMove)
    }
  }, [])

  return (
    <div
      ref={heartRef}
      className={`heart-container ${isStory ? "heart-story" : ""} relative w-40 h-40 md:w-48 md:h-48 transform-style-3d transition-transform duration-300`}
    >
      <div className="heart-shape absolute w-full h-full animate-heartbeat">
        <div className="heart-half heart-left"></div>
        <div className="heart-half heart-right"></div>
      </div>
      <div className="heart-glow absolute w-full h-full animate-pulse opacity-70 blur-md">
        <div className="heart-half heart-left"></div>
        <div className="heart-half heart-right"></div>
      </div>
    </div>
  )
}

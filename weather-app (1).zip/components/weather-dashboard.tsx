"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight } from "lucide-react"
import WeatherCard from "./weather-card"
import WeatherCarousel from "./weather-carousel"

// Mock data for the past 7 days
const weatherData = [
  {
    date: new Date(),
    condition: "sunny",
    temperature: 28,
    feelsLike: 30,
    humidity: 45,
    windSpeed: 10,
    hourlyForecast: [
      { time: "6AM", temp: 22, condition: "sunny" },
      { time: "9AM", temp: 24, condition: "sunny" },
      { time: "12PM", temp: 28, condition: "sunny" },
      { time: "3PM", temp: 30, condition: "sunny" },
      { time: "6PM", temp: 26, condition: "sunny" },
      { time: "9PM", temp: 23, condition: "clear" },
    ],
  },
  {
    date: new Date(Date.now() - 86400000),
    condition: "partly-cloudy",
    temperature: 26,
    feelsLike: 28,
    humidity: 50,
    windSpeed: 12,
    hourlyForecast: [
      { time: "6AM", temp: 20, condition: "cloudy" },
      { time: "9AM", temp: 22, condition: "partly-cloudy" },
      { time: "12PM", temp: 26, condition: "partly-cloudy" },
      { time: "3PM", temp: 28, condition: "partly-cloudy" },
      { time: "6PM", temp: 25, condition: "partly-cloudy" },
      { time: "9PM", temp: 22, condition: "clear" },
    ],
  },
  {
    date: new Date(Date.now() - 2 * 86400000),
    condition: "rainy",
    temperature: 22,
    feelsLike: 20,
    humidity: 75,
    windSpeed: 15,
    hourlyForecast: [
      { time: "6AM", temp: 18, condition: "cloudy" },
      { time: "9AM", temp: 19, condition: "rainy" },
      { time: "12PM", temp: 22, condition: "rainy" },
      { time: "3PM", temp: 23, condition: "rainy" },
      { time: "6PM", temp: 21, condition: "rainy" },
      { time: "9PM", temp: 19, condition: "cloudy" },
    ],
  },
  {
    date: new Date(Date.now() - 3 * 86400000),
    condition: "cloudy",
    temperature: 24,
    feelsLike: 25,
    humidity: 60,
    windSpeed: 8,
    hourlyForecast: [
      { time: "6AM", temp: 19, condition: "cloudy" },
      { time: "9AM", temp: 21, condition: "cloudy" },
      { time: "12PM", temp: 24, condition: "cloudy" },
      { time: "3PM", temp: 25, condition: "partly-cloudy" },
      { time: "6PM", temp: 23, condition: "partly-cloudy" },
      { time: "9PM", temp: 20, condition: "clear" },
    ],
  },
  {
    date: new Date(Date.now() - 4 * 86400000),
    condition: "clear",
    temperature: 27,
    feelsLike: 29,
    humidity: 40,
    windSpeed: 5,
    hourlyForecast: [
      { time: "6AM", temp: 21, condition: "clear" },
      { time: "9AM", temp: 23, condition: "sunny" },
      { time: "12PM", temp: 27, condition: "sunny" },
      { time: "3PM", temp: 29, condition: "sunny" },
      { time: "6PM", temp: 26, condition: "clear" },
      { time: "9PM", temp: 22, condition: "clear" },
    ],
  },
  {
    date: new Date(Date.now() - 5 * 86400000),
    condition: "stormy",
    temperature: 20,
    feelsLike: 18,
    humidity: 85,
    windSpeed: 25,
    hourlyForecast: [
      { time: "6AM", temp: 17, condition: "cloudy" },
      { time: "9AM", temp: 18, condition: "rainy" },
      { time: "12PM", temp: 20, condition: "stormy" },
      { time: "3PM", temp: 19, condition: "stormy" },
      { time: "6PM", temp: 18, condition: "rainy" },
      { time: "9PM", temp: 17, condition: "cloudy" },
    ],
  },
  {
    date: new Date(Date.now() - 6 * 86400000),
    condition: "partly-cloudy",
    temperature: 25,
    feelsLike: 26,
    humidity: 55,
    windSpeed: 10,
    hourlyForecast: [
      { time: "6AM", temp: 20, condition: "clear" },
      { time: "9AM", temp: 22, condition: "partly-cloudy" },
      { time: "12PM", temp: 25, condition: "partly-cloudy" },
      { time: "3PM", temp: 26, condition: "partly-cloudy" },
      { time: "6PM", temp: 24, condition: "partly-cloudy" },
      { time: "9PM", temp: 21, condition: "clear" },
    ],
  },
]

export default function WeatherDashboard() {
  const [currentDayIndex, setCurrentDayIndex] = useState(0)

  const handlePrevDay = () => {
    setCurrentDayIndex((prev) => (prev === weatherData.length - 1 ? 0 : prev + 1))
  }

  const handleNextDay = () => {
    setCurrentDayIndex((prev) => (prev === 0 ? weatherData.length - 1 : prev - 1))
  }

  const formatDate = (date: Date) => {
    return date.toLocaleDateString("en-US", {
      weekday: "long",
      month: "long",
      day: "numeric",
    })
  }

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold text-center mb-8 text-sky-900">7-Day Weather Forecast</h1>

      <div className="flex items-center justify-between mb-4">
        <Button variant="outline" onClick={handlePrevDay} className="bg-white hover:bg-sky-50">
          <ChevronLeft className="mr-1" /> Previous
        </Button>
        <h2 className="text-xl font-semibold text-sky-800">
          {currentDayIndex === 0 ? "Today" : formatDate(weatherData[currentDayIndex].date)}
        </h2>
        <Button variant="outline" onClick={handleNextDay} className="bg-white hover:bg-sky-50">
          Next <ChevronRight className="ml-1" />
        </Button>
      </div>

      <Card className="mb-8 bg-white/80 backdrop-blur-sm shadow-lg">
        <CardContent className="p-6">
          <WeatherCard weatherData={weatherData[currentDayIndex]} isToday={currentDayIndex === 0} />
        </CardContent>
      </Card>

      <WeatherCarousel
        weatherData={weatherData}
        currentDayIndex={currentDayIndex}
        setCurrentDayIndex={setCurrentDayIndex}
      />
    </div>
  )
}

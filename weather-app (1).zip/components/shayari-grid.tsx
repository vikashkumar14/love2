"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { shayariData } from "@/data/shayari-data"

export default function ShayariGrid() {
  const [expandedIndex, setExpandedIndex] = useState<number | null>(null)

  const handleClick = (index: number) => {
    setExpandedIndex(expandedIndex === index ? null : index)
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-24">
      {shayariData.map((shayari, index) => (
        <motion.button
          key={index}
          className={`shayari-button button-${(index % 20) + 1} p-5 rounded-xl text-white font-medium text-lg shadow-glow overflow-hidden relative`}
          onClick={() => handleClick(index)}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.05 }}
          whileHover={{ scale: 1.03, y: -5 }}
          whileTap={{ scale: 0.98 }}
        >
          <span className="relative z-10">{shayari}</span>
          <div className="absolute inset-0 bg-gradient-to-br from-transparent to-black/20 z-0"></div>
          <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-r from-white/20 to-transparent -translate-x-full hover:translate-x-full transition-transform duration-700 z-0"></div>
        </motion.button>
      ))}
    </div>
  )
}

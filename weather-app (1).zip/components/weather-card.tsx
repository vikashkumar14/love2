import { Cloud, CloudRain, CloudSnow, CloudSun, Droplets, Sun, Thermometer, Wind, CloudLightning } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

interface HourlyForecast {
  time: string
  temp: number
  condition: string
}

interface WeatherData {
  date: Date
  condition: string
  temperature: number
  feelsLike: number
  humidity: number
  windSpeed: number
  hourlyForecast: HourlyForecast[]
}

interface WeatherCardProps {
  weatherData: WeatherData
  isToday: boolean
}

export default function WeatherCard({ weatherData, isToday }: WeatherCardProps) {
  const getWeatherIcon = (condition: string, size = 24) => {
    switch (condition) {
      case "sunny":
        return <Sun size={size} className="text-amber-500" />
      case "clear":
        return <Sun size={size} className="text-amber-500" />
      case "partly-cloudy":
        return <CloudSun size={size} className="text-sky-500" />
      case "cloudy":
        return <Cloud size={size} className="text-gray-500" />
      case "rainy":
        return <CloudRain size={size} className="text-blue-500" />
      case "snowy":
        return <CloudSnow size={size} className="text-sky-200" />
      case "stormy":
        return <CloudLightning size={size} className="text-purple-500" />
      default:
        return <Sun size={size} className="text-amber-500" />
    }
  }

  const formatDate = (date: Date) => {
    return date.toLocaleDateString("en-US", {
      weekday: "long",
      month: "long",
      day: "numeric",
    })
  }

  return (
    <div>
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <div>
          <h3 className="text-2xl font-bold text-sky-900">{isToday ? "Today" : formatDate(weatherData.date)}</h3>
          <p className="text-sky-700">
            {new Date(weatherData.date).toLocaleDateString("en-US", {
              year: "numeric",
            })}
          </p>
        </div>
        <div className="flex items-center mt-4 md:mt-0">
          <div className="mr-4">{getWeatherIcon(weatherData.condition, 48)}</div>
          <div>
            <div className="text-4xl font-bold text-sky-900">{weatherData.temperature}°C</div>
            <div className="text-sky-700">Feels like {weatherData.feelsLike}°C</div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-8">
        <div className="flex items-center">
          <Thermometer className="mr-2 text-rose-500" />
          <div>
            <p className="text-sm text-gray-500">Temperature</p>
            <p className="font-medium">{weatherData.temperature}°C</p>
          </div>
        </div>
        <div className="flex items-center">
          <Droplets className="mr-2 text-blue-500" />
          <div>
            <p className="text-sm text-gray-500">Humidity</p>
            <p className="font-medium">{weatherData.humidity}%</p>
          </div>
        </div>
        <div className="flex items-center">
          <Wind className="mr-2 text-sky-500" />
          <div>
            <p className="text-sm text-gray-500">Wind</p>
            <p className="font-medium">{weatherData.windSpeed} km/h</p>
          </div>
        </div>
      </div>

      <h4 className="text-lg font-semibold text-sky-900 mb-4">Hourly Forecast</h4>
      <div className="grid grid-cols-3 md:grid-cols-6 gap-2">
        {weatherData.hourlyForecast.map((hour, index) => (
          <Card key={index} className="bg-sky-50 border-sky-100">
            <CardContent className="p-3 flex flex-col items-center">
              <p className="text-sm font-medium text-sky-900">{hour.time}</p>
              {getWeatherIcon(hour.condition, 20)}
              <p className="text-sm font-bold mt-1">{hour.temp}°C</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

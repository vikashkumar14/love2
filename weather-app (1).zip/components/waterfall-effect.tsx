"use client"

import { useEffect, useState } from "react"

interface WaterDrop {
  id: number
  left: number
  height: number
  duration: number
  delay: number
}

export default function WaterfallEffect() {
  const [waterDrops, setWaterDrops] = useState<WaterDrop[]>([])

  useEffect(() => {
    // Create initial water drops
    const initialDrops: WaterDrop[] = []
    for (let i = 0; i < 20; i++) {
      initialDrops.push(createWaterDrop())
    }
    setWaterDrops(initialDrops)

    // Add new drops periodically
    const interval = setInterval(() => {
      setWaterDrops((prev) => {
        // Remove old drops to prevent too many elements
        if (prev.length > 50) {
          const newDrops = [...prev]
          newDrops.shift()
          return [...newDrops, createWaterDrop()]
        }
        return [...prev, createWaterDrop()]
      })
    }, 200)

    return () => {
      clearInterval(interval)
    }
  }, [])

  // Function to create a new water drop
  function createWaterDrop(): WaterDrop {
    return {
      id: Date.now() + Math.random(),
      left: Math.random() * 100,
      height: Math.random() * 100 + 50,
      duration: Math.random() * 2 + 2,
      delay: Math.random() * 0.5,
    }
  }

  return (
    <div className="fixed bottom-0 left-0 w-full h-[300px] pointer-events-none z-0" aria-hidden="true">
      <div className="absolute inset-0 bg-gradient-to-t from-blue-500/30 to-transparent"></div>

      {waterDrops.map((drop) => (
        <div
          key={drop.id}
          className="absolute w-[2px] bg-white/70 rounded-t-full animate-water-fall"
          style={{
            left: `${drop.left}%`,
            height: `${drop.height}px`,
            animationDuration: `${drop.duration}s`,
            animationDelay: `${drop.delay}s`,
          }}
        ></div>
      ))}
    </div>
  )
}

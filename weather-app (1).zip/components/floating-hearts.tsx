"use client"

import { useEffect, useState } from "react"

interface FloatingHeart {
  id: number
  x: number
  y: number
  size: number
  speed: number
  opacity: number
  rotation: number
  rotationSpeed: number
}

interface FloatingHeartsProps {
  count?: number
}

export default function FloatingHearts({ count = 10 }: FloatingHeartsProps) {
  const [hearts, setHearts] = useState<FloatingHeart[]>([])

  useEffect(() => {
    // Create initial hearts
    const initialHearts: FloatingHeart[] = []
    for (let i = 0; i < count; i++) {
      initialHearts.push(createHeart())
    }
    setHearts(initialHearts)

    // Animation frame
    let animationId: number
    let lastTime = 0

    const animate = (timestamp: number) => {
      const deltaTime = timestamp - lastTime
      lastTime = timestamp

      setHearts((prevHearts) =>
        prevHearts.map((heart) => {
          // Update position
          const newY = heart.y - heart.speed * (deltaTime / 16)

          // If heart has gone off screen, reset it at the bottom
          if (newY < -100) {
            return createHeart()
          }

          // Update rotation
          const newRotation = heart.rotation + heart.rotationSpeed * (deltaTime / 16)

          return {
            ...heart,
            y: newY,
            rotation: newRotation,
          }
        }),
      )

      animationId = requestAnimationFrame(animate)
    }

    animationId = requestAnimationFrame(animate)

    return () => {
      cancelAnimationFrame(animationId)
    }
  }, [count])

  // Function to create a new heart
  function createHeart(): FloatingHeart {
    return {
      id: Math.random(),
      x: Math.random() * 100, // percentage of screen width
      y: 100 + Math.random() * 50, // start below the screen
      size: Math.random() * 30 + 10,
      speed: Math.random() * 0.5 + 0.2,
      opacity: Math.random() * 0.6 + 0.2,
      rotation: Math.random() * 360,
      rotationSpeed: (Math.random() - 0.5) * 2,
    }
  }

  return (
    <div className="fixed inset-0 pointer-events-none z-0" aria-hidden="true">
      {hearts.map((heart) => (
        <div
          key={heart.id}
          className="absolute text-red-500"
          style={{
            left: `${heart.x}%`,
            top: `${heart.y}%`,
            fontSize: `${heart.size}px`,
            opacity: heart.opacity,
            transform: `rotate(${heart.rotation}deg)`,
            transition: "transform 0.5s ease-out",
          }}
        >
          ❤️
        </div>
      ))}
    </div>
  )
}

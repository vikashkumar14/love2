"use client"

import { useState, useEffect } from "react"

export default function LoveNotes() {
  const [notes, setNotes] = useState<{ id: number; x: number; y: number; opacity: number }[]>([])

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      // Only create a note every 100ms to avoid too many notes
      if (Math.random() > 0.9) {
        const newNote = {
          id: Date.now(),
          x: e.clientX,
          y: e.clientY,
          opacity: 1,
        }

        setNotes((prev) => [...prev, newNote])

        // Remove note after animation completes
        setTimeout(() => {
          setNotes((prev) => prev.filter((note) => note.id !== newNote.id))
        }, 2000)
      }
    }

    window.addEventListener("mousemove", handleMouseMove)

    return () => {
      window.removeEventListener("mousemove", handleMouseMove)
    }
  }, [])

  return (
    <>
      {notes.map((note) => (
        <div
          key={note.id}
          className="love-note fixed pointer-events-none text-yellow-300 font-dancing text-2xl animate-float-up z-50"
          style={{
            left: `${note.x - 100}px`,
            top: `${note.y - 25}px`,
            textShadow: "0 0 10px #ff0, 0 0 20px #ff4500",
          }}
        >
          I Love You Renu Meri Jaan 💖
        </div>
      ))}
    </>
  )
}

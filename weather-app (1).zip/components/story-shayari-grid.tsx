"use client"

import type React from "react"

import { useState } from "react"
import { motion } from "framer-motion"
import { storyShayariData } from "@/data/story-shayari-data"

export default function StoryShayariGrid() {
  const [expandedIndex, setExpandedIndex] = useState<number | null>(null)

  const handleClick = (index: number) => {
    setExpandedIndex(expandedIndex === index ? null : index)
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-24 max-w-4xl mx-auto">
      {storyShayariData.map((shayari, index) => (
        <motion.button
          key={index}
          className={`shayari-button p-5 rounded-xl text-white font-medium text-lg shadow-glow overflow-hidden relative`}
          style={
            {
              background: `linear-gradient(45deg, var(--start-color-${index % 4}), var(--end-color-${index % 4}))`,
              "--start-color-0": "#ff4b2b",
              "--end-color-0": "#ff416c",
              "--start-color-1": "#11998e",
              "--end-color-1": "#38ef7d",
              "--start-color-2": "#8E2DE2",
              "--end-color-2": "#4A00E0",
              "--start-color-3": "#ee0979",
              "--end-color-3": "#ff6a00",
            } as React.CSSProperties
          }
          onClick={() => handleClick(index)}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.05 }}
          whileHover={{ scale: 1.03, y: -5 }}
          whileTap={{ scale: 0.98 }}
        >
          <span className="relative z-10">{shayari}</span>
          <div className="absolute inset-0 bg-gradient-to-br from-transparent to-black/20 z-0"></div>
          <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-r from-white/20 to-transparent -translate-x-full hover:translate-x-full transition-transform duration-700 z-0"></div>
        </motion.button>
      ))}
    </div>
  )
}
